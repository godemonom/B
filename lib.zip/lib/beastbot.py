import telebot, time, json
from pymongo import MongoClient

bot_token = "7446388449:AAHcarCNRoJpBxiLa-Iok6LSvpmBibRsMV4" # bot token here
bot = telebot.TeleBot(bot_token)

client = MongoClient('mongodb+srv://payalsahu2611814:7OkHAPV72qoQx8xa@beast.61pqhpu.mongodb.net')
db = client.asheodb
collection = db.asheofree

user_login_status = {}

try:
    with open('login_status.txt', 'r') as file:
        user_login_status = json.load(file)
except FileNotFoundError:
    user_login_status = {}

def save_login_status():
    with open('login_status.txt', 'w') as file:
        json.dump(user_login_status, file)

def authenticate_user(username, password):
    user = collection.find_one({"username": username, "password": password})
    return user is not None

@bot.message_handler(commands=['login'])
async def login(message):
    try:
        command_parts = message.text.split()
        username = command_parts[1]
        password = command_parts[2]
    except IndexError:
        await bot.send_message(message.chat.id, "Please provide both username and password.")
        return

    if authenticate_user(username, password):
        user_id = message.from_user.id
        user_login_status[user_id] = username
        save_login_status()
        await bot.send_message(message.chat.id, "You are now logged in.")
    else:
        await bot.send_message(message.chat.id, "Invalid username or password.")

@bot.message_handler(commands=['logout'])
async def logout(message):
    user_id = message.from_user.id
    if user_id in user_login_status:
        del user_login_status[user_id]
        save_login_status()
        await bot.send_message(message.chat.id, "You are now logged out.")
    else:
        await bot.send_message(message.chat.id, "You are not logged in.")

def is_logged_in(user_id):
    return user_id in user_login_status

def get_username_for_user(user_id):
    if is_logged_in(user_id):
        return user_login_status[user_id]
    else:
        return None

@bot.message_handler(commands=['fingerprint'])
async def changebin(message):
    user_id = message.from_user.id
    if is_logged_in(user_id):
        username = get_username_for_user(user_id)
        try:
            new_fp = message.text.split()[1]
        except IndexError:
            await bot.send_message(message.chat.id, "Please provide the new fingerprint.")
            return
        user = collection.find_one({"username": username})
        if user:
            await collection.update_one({"_id": user["_id"]}, {"$set": {"fingerprint": new_fp}})
            await bot.send_message(message.chat.id, f"Fingerprint Update\nFingerprint for {username} updated to {new_fp}", reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to_message_id=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You need to login to perform this action.")

@bot.message_handler(commands=['changebin'])
async def changebin(message):
    user_id = message.from_user.id
    if is_logged_in(user_id):
        username = get_username_for_user(user_id)
        try:
            new_bin = message.text.split()[1]
        except IndexError:
            await bot.send_message(message.chat.id, "Please provide the new bin.")
            return
        user = collection.find_one({"username": username})
        if user:
            await collection.update_one({"_id": user["_id"]}, {"$set": {"bin": new_bin}})
            await bot.send_message(message.chat.id, f"BIN Update\nBIN for {username} updated to {new_bin}", reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to_message_id=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You need to login to perform this action.")

@bot.message_handler(commands=['changeproxy'])
async def changebin(message):
    user_id = message.from_user.id
    if is_logged_in(user_id):
        username = get_username_for_user(user_id)
        try:
            new_proxy = message.text.split()[1]
        except IndexError:
            await bot.send_message(message.chat.id, "Please provide the new proxy.")
            return
        user = collection.find_one({"username": username})
        if user:
            await collection.update_one({"_id": user["_id"]}, {"$set": {"proxy": new_proxy}})
            await bot.send_message(message.chat.id, f"Proxy Update\nProxy for {username} updated to {new_proxy}", reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to_message_id=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You need to login to perform this action.")

@bot.message_handler(commands=['showsettings'])
async def changebin(message):
    user_id = message.from_user.id
    if is_logged_in(user_id):
        username = get_username_for_user(user_id)
        user = collection.find_one({"username": username})
        if user:
            settings_message = f"User Information\n"
            settings_message += f"Username: {user['username']}\n"
            settings_message += f"Password: {user['password']}\n"
            settings_message += f"Bin: {user['bin']}\n"
            settings_message += f"Proxy: {user['proxy']}\n"
            settings_message += f"Fingerprint: {user['fingerprint']}"
            settings_message += f"Role: {user['role']}"

            await bot.send_message(message.chat.id, settings_message, reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to_message_id=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You need to login to perform this action.")

@bot.message_handler(commands=['userrole'])
async def userrole(message):
    user_id = message.from_user.id
    if is_logged_in(user_id):
        username = get_username_for_user(user_id)
        user = collection.find_one({"username": username})
        if user:
            settings_message = f"User Role\n"
            settings_message += f"Role: {user['role']}"

            await bot.send_message(message.chat.id, settings_message, reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to_message_id=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You need to login to perform this action.")

@bot.message_handler(commands=['resetlog'])
async def changebin(message):
    user_id = message.from_user.id
    if is_logged_in(user_id):
        username = get_username_for_user(user_id)
        user = collection.find_one({"username": username})
        if user:
            await collection.update_one({"_id": user["_id"]}, {"$set": {"logs": ["white:white:Welcome to asheo!"]}})
            await bot.send_message(message.chat.id, f"Log Reset\nReset logs for {username}", reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to_message_id=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You need to login to perform this action.")

# admin cmds

admin_user_ids = [1984468312]

@bot.message_handler(commands=['seerole'])
async def seerole(message):
    user_id = message.from_user.id
    if user_id in admin_user_ids:
        command_parts = message.text.split()
        username = command_parts[1]

        user = collection.find_one({"username": username})

        if user:
            settings_message = f"User Role\n"
            settings_message += f"Role: {user['role']}"
            
            await bot.send_message(message.chat.id, settings_message, reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You are not authorized to use this command.")

@bot.message_handler(commands=['forcefingerprint'])
async def forcefingerprint(message):
    user_id = message.from_user.id
    if user_id in admin_user_ids:
        command_parts = message.text.split()
        username = command_parts[1]
        new_fp = command_parts[2]

        user = collection.find_one({"username": username})

        if user:
            await collection.update_one({"_id": user["_id"]}, {"$set": {"fingerprint": new_fp}})
            
            await bot.send_message(message.chat.id, f"Fingerprint Update\nFingerprint for {username} updated to {new_fp}", reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You are not authorized to use this command.")

@bot.message_handler(commands=['changeplan'])
async def changeplan(message):
    user_id = message.from_user.id
    if user_id in admin_user_ids:
        command_parts = message.text.split()
        username = command_parts[1]
        plan = command_parts[2]

        user = collection.find_one({"username": username})

        if user:
            await collection.update_one({"_id": user["_id"]}, {"$set": {"role": plan}})
            
            await bot.send_message(message.chat.id, f"Plan Update\nPlan for {username} updated to {plan}", reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You are not authorized to use this command.")

@bot.message_handler(commands=['terminate'])
async def terminateusr(message):
    user_id = message.from_user.id
    if user_id in admin_user_ids:
        username = message.text.split()[1]

        user = collection.find_one({"username": username})

        if user:
            await collection.delete_one({"_id": user["_id"]})
            
            await bot.send_message(message.chat.id, f"User Deletion\nUser {username} has been deleted from the database.", reply_to_message_id=message.message_id, parse_mode="Markdown")
        else:
            await bot.send_message(message.chat.id, f"User Not Found\nUser {username} not found", reply_to_message_id=message.message_id, parse_mode="Markdown")
    else:
        await bot.send_message(message.chat.id, "You are not authorized to use this command.")

while True:
    try:
        bot.polling(none_stop=True)
        print("bot on")
    except Exception as e:
        print(e)
        time.sleep(15)
